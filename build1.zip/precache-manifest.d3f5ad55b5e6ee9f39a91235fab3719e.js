self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8e533dba7357d6e1e0e360b8a9e172cc",
    "url": "/index.html"
  },
  {
    "revision": "5eed81b6fbf2c2f4f587",
    "url": "/static/css/2.903596ff.chunk.css"
  },
  {
    "revision": "81e9f94746a35a27d418",
    "url": "/static/css/main.12905044.chunk.css"
  },
  {
    "revision": "5eed81b6fbf2c2f4f587",
    "url": "/static/js/2.56344f57.chunk.js"
  },
  {
    "revision": "64ea1a1d9d16ae312e6f8ac0b0cd1b4a",
    "url": "/static/js/2.56344f57.chunk.js.LICENSE.txt"
  },
  {
    "revision": "81e9f94746a35a27d418",
    "url": "/static/js/main.1e52fccd.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "/static/js/main.1e52fccd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "be46ec2abecfaed2158c",
    "url": "/static/js/runtime-main.40c6c874.js"
  },
  {
    "revision": "3406c81cd92f6804fbdf48d98bda5048",
    "url": "/static/media/arrow-thick-down.3406c81c.svg"
  },
  {
    "revision": "613356a4c8926c03b79bba6a3560b4ac",
    "url": "/static/media/arrow-thick-up.613356a4.svg"
  },
  {
    "revision": "bb95fc8d18138ecf46a3da8345912f29",
    "url": "/static/media/awaiting-acceptance.bb95fc8d.svg"
  },
  {
    "revision": "761eacd17881188fcb2300f4ec68718e",
    "url": "/static/media/bug.761eacd1.svg"
  },
  {
    "revision": "284f3f0389b105dc7629dadc307b54ad",
    "url": "/static/media/checkmark.284f3f03.svg"
  },
  {
    "revision": "35de839ef559736545e77c97e6d65afe",
    "url": "/static/media/icon-check-circle.35de839e.svg"
  },
  {
    "revision": "040ad82553f22c7d77c903c7bbc4ef9d",
    "url": "/static/media/icon-edit.040ad825.svg"
  },
  {
    "revision": "297e854fe58256020de9cbde7deaebb1",
    "url": "/static/media/icon-trash.297e854f.svg"
  },
  {
    "revision": "977157ccd4940d51042684e1a503a1f4",
    "url": "/static/media/icon-x-circle.977157cc.svg"
  },
  {
    "revision": "eacd4f57af0617a2a428287b67384239",
    "url": "/static/media/icon-x.eacd4f57.svg"
  },
  {
    "revision": "23936c7bf2aa6a83aea23d6747496431",
    "url": "/static/media/mood-happy-solid.23936c7b.svg"
  },
  {
    "revision": "8774d16f46610a536d944f44631edda5",
    "url": "/static/media/show-sidebar.8774d16f.svg"
  },
  {
    "revision": "a7bbfcf777c880add42566f3b63da739",
    "url": "/static/media/ticket.a7bbfcf7.svg"
  },
  {
    "revision": "1c9f3df58998c7e99d3e973309795091",
    "url": "/static/media/user-add.1c9f3df5.svg"
  },
  {
    "revision": "567eb43a56c1fbb1b054322d842990ea",
    "url": "/static/media/user-group.567eb43a.svg"
  },
  {
    "revision": "1cddcfc3924a72907f44f2aaca9d5311",
    "url": "/static/media/watermelon-pack-illustration-02.1cddcfc3.svg"
  },
  {
    "revision": "035200549723ad28d09af7de1105760d",
    "url": "/static/media/watermelon-pack-illustration-05.03520054.svg"
  },
  {
    "revision": "7214738150739cb00157d79a4e00640e",
    "url": "/static/media/watermelon-pack-illustration-07.72147381.svg"
  },
  {
    "revision": "1023e7ae8ea7286c19cbaafe9678fd88",
    "url": "/static/media/watermelon-pack-illustration-10.1023e7ae.svg"
  },
  {
    "revision": "819f8b7fb4ef0d4f1f8c4cb2455dfa4d",
    "url": "/static/media/watermelon-pack-illustration-14.819f8b7f.svg"
  },
  {
    "revision": "848c57216c874b0863af5e7ee4860c2d",
    "url": "/static/media/watermelon-pack-illustration-15.848c5721.svg"
  },
  {
    "revision": "f44c5b70f1f52ebf6263ef77405f32ed",
    "url": "/static/media/watermelon-pack-illustration-18.f44c5b70.svg"
  },
  {
    "revision": "cc05ea20ba285a41ff08ace9df1433a3",
    "url": "/static/media/watermelon-pack-illustration-20.cc05ea20.svg"
  }
]);