import React from 'react';
import { Link } from 'react-router-dom';

const DropdownLink = ({ to, children, handleOnClick }) => (
	<Link
		to={to ? to : ''}
		className="block px-4 py-2 text-sm leading-5 text-gray-700 hover:bg-gray-100 hover:text-gray-900 focus:outline-none focus:bg-gray-100 focus:text-gray-900"
		role="menuitem"
		onClick={handleOnClick}
	>
		{children}
	</Link>
);

export default DropdownLink;
