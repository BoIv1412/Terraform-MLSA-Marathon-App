declare module 'tailwind.macro';
